/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package quizapprasha;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;


import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class QUIZ {

	 JFrame frame;


	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		 
		
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					QUIZ window = new QUIZ();
					window.frame.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public QUIZ() {
		initialize();

	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
	//	frame.setIconImage(Toolkit.getDefaultToolkit().getImage(QUIZ.class.getResource("/icons/full/help.png")));
		frame.setBackground(Color.YELLOW);
		frame.getContentPane().setFont(new Font("Tahoma", Font.BOLD, 11));
		frame.setResizable(false);
		frame.getContentPane().setBackground(Color.ORANGE);		
		Image imgBP= new ImageIcon(this.getClass().getResource("/quizapprasha/IMAGES/PLAY (2).png")).getImage();
		JButton play = new JButton(new ImageIcon(imgBP));
		
		Thread playWave4=new AePlayWave("src/quizapprasha/sounds/button-10.wav");
		
		
		//playWave4.start();
	
		play.setBounds(152, 377, 170, 75);
	//	play.setFont(new Font("Tw Cen MT", Font.BOLD, 17));
		//play.setForeground(Color.ORANGE);
	//	play.setBackground(Color.ORANGE);
		play.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			 Catges c= new Catges();
			 
			// Thread playWave4=new AePlayWave("sounds/button-10.wav");
				
				
				playWave4.start();
			
				
			 c.Categs.setVisible(true);
			 
			 frame.dispose();
			}
		});
		frame.getContentPane().setLayout(null);
		frame.getContentPane().add(play);
		Image imgBM= new ImageIcon(this.getClass().getResource("/quizapprasha/IMAGES/MENU (2).png")).getImage();

		JButton menu = new JButton(new ImageIcon(imgBM));
		menu.setBackground(Color.ORANGE);
		menu.setForeground(Color.ORANGE);
		menu.setBounds(152, 456, 170, 75);
		//	menu.setFont(new Font("Tw Cen MT", Font.BOLD, 17));
		//menu.setBackground(Color.black);
	//	menu.setForeground(Color.RED);
		menu.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				Menu c= new Menu();
				
				//Thread playWave4=new AePlayWave("sounds/button-10.wav");
				
				
				playWave4.start();
			
				
				 c.frameMenu.setVisible(true);
				 frame.dispose();
				 
			}
		});
		
		
		frame.getContentPane().add(menu);
		
		JLabel lblNewLabel = new JLabel("");
		Image img= new ImageIcon(this.getClass().getResource("/quizapprasha/IMAGES/Copy of Yellow Bulb Playful Pop of Color Education Logo (1).png")).getImage();
		lblNewLabel.setIcon(new ImageIcon(img));
		lblNewLabel.setBounds(0, 0, 576, 670);
		frame.getContentPane().add(lblNewLabel);
		
		
		
		
		frame.setBounds(0, 0, 500, 700);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	 
}
