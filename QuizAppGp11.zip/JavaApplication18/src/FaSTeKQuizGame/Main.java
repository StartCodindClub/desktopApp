package FaSTeKQuizGame ;

// safa benabdessadouk
public class Main {

 	public static void main(String[] args) {
		
		new WelcomeWindow();

	}
}
