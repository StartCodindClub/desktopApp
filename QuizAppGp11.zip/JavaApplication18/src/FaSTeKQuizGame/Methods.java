package FaSTeKQuizGame;

import java.awt.*;
import java.io.*;
import java.util.Random;

public abstract class Methods {
	
	static Color backgroundColor = new Color(43,43,43); 
	static Color foregroundColor = new Color(240,240,240);
	static Color borderColor = new Color(189,81,81);

	public static void ChangeColor(Color bC){
		borderColor = bC;
	}
	/* -/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/- */

    static int [] c ; 
    static int index, i ,j ;
    static boolean v ;
    static Random rand = new Random();

    static void QuestionsIndex(int []cp){
        i = 0 ;
        c = cp ; 
        while( i != c.length ){
            v = true ;
            index = rand.nextInt(c.length+1);
            j = 0;
            while(v == true && j != c.length ){
                if(index == c[j])
                    v = false;
                j++;
            }       
            if(v == true){
                c[i] = index;
                i++;
            } 
        }
    }

    static int readBestScorefromTheFile(){
        try {
            FileReader isr = new FileReader("/best-score.txt");
			String str = "";
            int c ;
            while( ( c = isr.read() ) != -1){
                if(Character.isDigit(c))
                    str += (char)c;
            }
            if(str.equals(""))
                str = "0";
 
            isr.close();
            return Integer.parseInt(str);
        }
        catch(IOException e) {
        }
        return 0;
    }

    static void writeBestScoreInTheFile(){
        if ( (QuestionWindow.results() > readBestScorefromTheFile()) || ( QuestionWindowE.results() > readBestScorefromTheFile())){
            try {
                FileWriter fos = new FileWriter("src/FaSTeKQuizGame/best-score.txt");

		        if(QuestionWindow.results() > readBestScorefromTheFile())
                	fos.write(QuestionWindow.results()+"");
                    
	        	else 
                    fos.write(QuestionWindowE.results()+"");
             	
                fos.close();
            }
            catch(IOException e) {
            }
        }
    }
    
}
