/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculatrice;


import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
/**
 *
 * @authors DJABALI_NADHIR , BENZAOUI_ AYOUB,‎ SEBBANE_HANANE , NASS_RINE , MERAH_ZAHRA
 */
public class Calculatrice extends Application {
    // هنا قمنا بتعريف جميع الأشياء التي سنضعها في النافذة
    Button b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,x2,e,del,clear,cos,sin,tan,div,add,sub,mul,egale,v,sqr;
    TextField txt;
    Label old,operand;
    
    public double Old=0,N,n;
    public char op;
     // ÷ × - + سنستخدم هذه الدالة لتخزين ناتج جميع العمليات السابقة في كل مرة يتم فيها النقر على الأزرار
    private double calcule(double a , char c, double b){
        if(c=='+')
            return b+a;
        if(c=='-')
            return b-a;
        if(c=='*')
            return b*a;
        else if(c=='÷')
            return b/a;  
           else
             return 0;
    }
    @Override
    public void start(Stage stage) {
   // Image icon=new Image(getClass().getResourceAsStream("/images/logo2.png"));
     // stage.getIcons().add(icon);
      
    // هنا قمنا بإنشاء جميع الأشياء التي سنضعها في النافذة
    b0=new Button("0");   
    b1=new Button("1"); 
    b2=new Button("2");
    b3=new Button("3"); 
    b4=new Button("4"); 
    b5=new Button("5"); 
    b6=new Button("6"); 
    b7=new Button("7"); 
    b8=new Button("8"); 
    b9=new Button("9"); 
    v=new Button(","); 
    add=new Button("+"); 
    sub=new Button("-"); 
    div=new Button("÷"); 
    mul=new Button("×"); 
    cos=new Button("cos"); 
    sin=new Button("sin"); 
    tan=new Button("tan"); 
    clear=new Button("C"); 
    del=new Button("←"); 
    egale=new Button("="); 
    x2=new Button("x²"); 
    sqr=new Button("√x"); 
    e=new Button("exp"); 
    txt=new TextField("0");
    old=new Label("");
    operand=new Label("");
    
    // بشكل يدوي textField هنا قمنا بجعل المستخدم غير قادر على تعديل نص الكائن
    txt.setEditable(false);
    txt.setFocusTraversable(false);
    
    // هنا قمنا بتحديد حجم و موقع كل شيء أضفناه في النافذة
    b0.setPrefSize(70, 60);
    b1.setPrefSize(70, 60);
    b2.setPrefSize(70, 60);
    b3.setPrefSize(70, 60);
    b4.setPrefSize(70, 60);
    b5.setPrefSize(70, 60);
    b6.setPrefSize(70, 60);
    b7.setPrefSize(70, 60);
    b8.setPrefSize(70, 60);
    b9.setPrefSize(70, 60);
    add.setPrefSize(70, 60);
    sub.setPrefSize(70, 60);
    div.setPrefSize(70, 60);
    mul.setPrefSize(70, 60);
    e.setPrefSize(70, 60);
    clear.setPrefSize(70, 60);
    del.setPrefSize(70, 60);
    cos.setPrefSize(70, 60);
    sin.setPrefSize(70, 60);
    tan.setPrefSize(70, 60);
    x2.setPrefSize(70, 60);
    sqr.setPrefSize(70, 60);
    v.setPrefSize(70, 60);
    egale.setPrefSize(70, 60);
    old.setPrefSize(260, 20);
    old.setTranslateX(5);
    old.setTranslateY(10);
    operand.setPrefSize(15, 20);
    operand.setTranslateX(266);
    operand.setTranslateY(10);
    txt.setPrefSize(286, 50);
    txt.setTranslateX(5);
    txt.setTranslateY(35);
    
     // لتحديد نوع خط و حجم الأشياء التي سنضيفها في النافذة font سنستخدم الكائن
     Font font = Font.font("Calibri", FontWeight.NORMAL, 23);
     
        // هنا قمنا بتحديد حجم و نوع خط كل شيء أضفناه في النافذة
        b0.setFont(font);
        b1.setFont(font);
        b2.setFont(font);
        b3.setFont(font);
        b4.setFont(font);
        b5.setFont(font);
        b6.setFont(font);
        b7.setFont(font);
        b8.setFont(font);
        b9.setFont(font);
        v.setFont(font);
        egale.setFont(font);
        add.setFont(font);
        sub.setFont(font);
        mul.setFont(font);
        div.setFont(font);
        clear.setFont(font);
        e.setFont(font);
        x2.setFont(font);
        sqr.setFont(font);
        cos.setFont(font);
        tan.setFont(font);
        sin.setFont(font);
        txt.setFont(Font.font("Digital-7 Mono", FontWeight.BLACK, 25));
        old.setFont(Font.font("Monospaced", FontWeight.BOLD, 18));
        operand.setFont(Font.font("Monospaced", FontWeight.BOLD, 18));
        del.setFont(Font.font("Tahoma", FontWeight.BOLD, 18));
        
            // هنا قمنا بتحديد لون خط و خلفية كل شيء سنضيفه في النافذة
        old.setStyle("-fx-text-fill: cyan;");
        operand.setStyle("-fx-text-fill: red;");
        b0.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b1.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b2.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b3.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b4.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b5.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b6.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b7.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b8.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        b9.setStyle("-fx-text-fill: white; -fx-background-color: dimgray;");
        v.setStyle("-fx-text-fill: white; -fx-background-color: orangered;");
        add.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        sub.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        mul.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        div.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        egale.setStyle("-fx-text-fill: white; -fx-background-color: green;");
        clear.setStyle("-fx-text-fill: white; -fx-background-color: #E50101;");
        del.setStyle("-fx-text-fill: white; -fx-background-color: orangered;");
        e.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        sqr.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        x2.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        cos.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        sin.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
        tan.setStyle("-fx-text-fill: white; -fx-background-color: darkslategray;");
    
    HBox h1=new HBox(2, x2,sqr,e,clear);
    HBox h2=new HBox(2, cos,sin,tan,div);
    HBox h3=new HBox(2, b7,b8,b9,mul);
    HBox h4=new HBox(2, b4,b5,b6,sub);
    HBox h5=new HBox(2, b1,b2,b3,add);
    HBox h6=new HBox(2, del,b0,v,egale);
    VBox vb=new VBox(2, h1,h2,h3,h4,h5,h6);
    vb.setTranslateX(5);
    vb.setTranslateY(90);
    
    
    // يظهر ناحية اليمين txtو operand ,old هنا قمنا بجعل نص الكائنات
    old.setAlignment(Pos.CENTER_RIGHT);
    operand.setAlignment(Pos.CENTER_RIGHT);
    txt.setAlignment(Pos.CENTER_RIGHT);
    
    add.setOnMouseClicked((MouseEvent e)->{
         try{ if(!txt.getText().equals("") && !operand.getText().equals("") && !old.getText().equals("")){
              op=operand.getText().charAt(0);
              Old= Double.valueOf(txt.getText());
              N= Double.valueOf(old.getText());
              txt.setText(Double.toString(calcule(Old ,'+',N)));
              operand.setText("");
               old.setText("");
          }else if(!txt.getText().equals("") && operand.getText().equals("") && old.getText().equals("")){
                Old= Double.valueOf(txt.getText());
                txt.setText("");
                operand.setText("+");
                old.setText(Double.toString(Old));
                }else{
                 old.setText(Double.toString(Old));
                 operand.setText("+");}}
          catch(Exception ex){
               txt.setText("Error");
           }
       });
       sub.setOnMouseClicked((MouseEvent e)->
       {
        try{  if(!txt.getText().equals("") && !operand.getText().equals("") && !old.getText().equals("")){
              op=operand.getText().charAt(0);
              Old= Double.valueOf(txt.getText());
              N= Double.valueOf(old.getText());
              txt.setText(Double.toString(calcule(Old , '-',N)));
              operand.setText("");
               old.setText("");
          }else if(!txt.getText().equals("") && operand.getText().equals("") && old.getText().equals("")){
                Old= Double.valueOf(txt.getText());
                txt.setText("");
                operand.setText("-");
                old.setText(Double.toString(Old));
                }else{
                 old.setText(Double.toString(Old));
                 operand.setText("-");  }  }
          catch(Exception ex){
               txt.setText("Error");
           }
       });
        mul.setOnMouseClicked((MouseEvent e)->
       {
         try{ if(!txt.getText().equals("") && !operand.getText().equals("") && !old.getText().equals("")){
              op=operand.getText().charAt(0);
              Old= Double.valueOf(txt.getText());
              N= Double.valueOf(old.getText());
              txt.setText(Double.toString(calcule(Old , '*',N)));
              operand.setText("");
               old.setText("");
          }else if(!txt.getText().equals("") && operand.getText().equals("") && old.getText().equals("")){
                Old= Double.valueOf(txt.getText());
                txt.setText("");
                operand.setText("*");
                old.setText(Double.toString(Old));
                }else{
                 old.setText(Double.toString(Old));
                 operand.setText("*");  }}  
          catch(Exception ex){
               txt.setText("Error");
           }
       });
      
        div.setOnMouseClicked((MouseEvent e)->
       {
          try{ if(!txt.getText().equals("") && !operand.getText().equals("") && !old.getText().equals("")){
              op=operand.getText().charAt(0);
              Old= Double.valueOf(txt.getText());
              N= Double.valueOf(old.getText());
              txt.setText(""+calcule(Old, '÷',N));
              operand.setText("");
               old.setText("");
          }else if(!txt.getText().equals("") && operand.getText().equals("") && old.getText().equals("")){
                Old= Double.valueOf(txt.getText());
                txt.setText("");
                operand.setText("÷");
                old.setText(Double.toString(Old));
                }else{
                 old.setText(Double.toString(Old));
                 operand.setText("÷");  }   }
          catch(Exception ex){
               txt.setText("Error");
           }
       });
        egale.setOnMouseClicked((MouseEvent e)->
       {
           try{
          if(!txt.getText().equals("") && !operand.getText().equals("") && !old.getText().equals("")){
              op=operand.getText().charAt(0);
              Old= Double.valueOf(txt.getText());
              N= Double.valueOf(old.getText());
              txt.setText(Double.toString(calcule(Old , op,N)));
              operand.setText("");
               old.setText("");
          }else if(txt.getText().equals("") && !operand.getText().equals("") && !old.getText().equals("")){
                txt.setText(old.getText());
                operand.setText("");
                old.setText("");
                }else{
                 txt.setText(txt.getText());}}
           catch(Exception ex){
               txt.setText("Error");
           }
       });
        clear.setOnMouseClicked((MouseEvent e)->{
                N=0;
                Old=0;
                txt.setText("0");
                old.setText("");
                operand.setText("");
                });
        del.setOnMouseClicked((MouseEvent e)->{
             if (!txt.getText().isEmpty())
                    {
                        txt.setText(txt.getText().substring(0, txt.getText().length() - 1));
                    }
        });
         b0.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("0");
                    else
                        txt.setText(txt.getText() + "0");
        });
         b1.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("1");
                    else
                        txt.setText(txt.getText() + "1");
        });
        b2.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("2");
                    else
                        txt.setText(txt.getText() + "2");
        });
        b3.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("3");
                    else
                        txt.setText(txt.getText() + "3");
        });
        b4.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("4");
                    else
                        txt.setText(txt.getText() + "4");
        });
        b5.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("5");
                    else
                        txt.setText(txt.getText() + "5");
        });
        b6.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("6");
                    else
                        txt.setText(txt.getText() + "6");
        });
        b7.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("7");
                    else
                        txt.setText(txt.getText() + "7");
        });
        b8.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("8");
                    else
                        txt.setText(txt.getText() + "8");
        });
        b9.setOnMouseClicked((MouseEvent e)->{
                      if (txt.getText().equals("0"))
                        txt.setText("9");
                    else
                        txt.setText(txt.getText() + "9");
        });
        v.setOnMouseClicked((MouseEvent e)->{
                     if (txt.getText().equals("0") || txt.getText().isEmpty())
                        txt.setText("0.");
                    else if (!txt.getText().contains("."))
                        txt.setText(txt.getText() + ".");
        });
        cos.setOnMouseClicked((MouseEvent e)->{
                    if (!txt.getText().equals("")){
                       n=Double.valueOf(txt.getText());
                        txt.setText(Double.toString(Math.cos(n)));}
                    
        });
        sin.setOnMouseClicked((MouseEvent e)->{
                    if (!txt.getText().equals("")){
                       n=Double.valueOf(txt.getText());
                        txt.setText(Double.toString(Math.sin(n)));}
                    
        });
        tan.setOnMouseClicked((MouseEvent e)->{
                    if (!txt.getText().equals("")){
                       n=Double.valueOf(txt.getText());
                        txt.setText(Double.toString(Math.tan(n)));}
                    
        });
        sqr.setOnMouseClicked((MouseEvent e)->{
                    if (!txt.getText().equals("")){
                       n=Double.valueOf(txt.getText());
                        txt.setText(Double.toString(Math.sqrt(n)));}
                    
        });
        e.setOnMouseClicked((MouseEvent e)->{
                    if (!txt.getText().equals("")){
                       n=Double.valueOf(txt.getText());
                        txt.setText(Double.toString(Math.exp(n)));}
                    
        });
        x2.setOnMouseClicked((MouseEvent e)->{
                    if (!txt.getText().equals("")){
                       n=Double.valueOf(txt.getText());
                        txt.setText(Double.toString(n*n));}
                    
        });
    
    Group root=new Group(old,operand,txt,vb);
    Scene scene=new Scene(root,287,457);
    scene.setFill(Color.web("#05223B"));
    stage.setResizable(false);
    stage.setScene(scene);
    stage.initStyle(StageStyle.DECORATED);
    stage.setTitle("Calculator");
    stage.show();

    }

 
    public static void main(String[] args) {
        launch(args);
    }
    
}
