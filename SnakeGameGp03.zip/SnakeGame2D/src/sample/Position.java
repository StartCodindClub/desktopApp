package sample;

public class Position {

    // every part of the snake will be shown along side the x and y axes
    int x, y;

   // we created this constructor to locate where's the snake during the game
    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }
}
