package gamesnake;

import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Font;
import javax.swing.JButton;

public class desin {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					desin window = new desin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public desin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 503, 500);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		JLabel lblNewLabel_1 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/gamesnake/images/back.jpg")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		lblNewLabel_1.setBackground(Color.WHITE);
		lblNewLabel_1.setForeground(Color.WHITE);
		lblNewLabel_1.setBounds(0, 0, 487, 461);
		frame.getContentPane().add(lblNewLabel_1);
		Image img2 = new ImageIcon(this.getClass().getResource("/gamesnake/images/snake.png")).getImage();
		Image img3 = new ImageIcon(this.getClass().getResource("/gamesnake/images/apple-icon.png")).getImage();
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel_1.add(lblNewLabel);
		
		lblNewLabel.setIcon(new ImageIcon(img2));
		lblNewLabel.setBackground(Color.WHITE);
		lblNewLabel.setForeground(Color.WHITE);
		lblNewLabel.setBounds(336, 264, 128, 148);
		JLabel lblNewLabel2 = new JLabel("");
		lblNewLabel_1.add(lblNewLabel2);
		
		lblNewLabel2.setIcon(new ImageIcon(img3));
		lblNewLabel2.setBackground(Color.WHITE);
		lblNewLabel2.setForeground(Color.WHITE);
		lblNewLabel2.setBounds(317, 336, 128, 148);
		
		JLabel lblNewLabel_2 = new JLabel("Snake Game");
		lblNewLabel_2.setFont(new Font("Algerian", Font.PLAIN, 48));
		lblNewLabel_2.setBounds(97, 53, 335, 79);
		lblNewLabel_1.add(lblNewLabel_2);
		
		JButton btnNewButton = new JButton("Start");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				btnNewButton.addActionListener(new ActionListener() {
					

					@Override
					public void actionPerformed(ActionEvent e) {
						 EventQueue.invokeLater(() -> {
							 Snake ex = new Snake();
					            ex.setVisible(true);
					        });
						
					}
				});
				
			}
		});
		btnNewButton.setBackground(Color.WHITE);
		btnNewButton.setFont(new Font("Algerian", Font.PLAIN, 16));
		btnNewButton.setBounds(85, 325, 137, 47);
		lblNewLabel_1.add(btnNewButton);
	}
}
