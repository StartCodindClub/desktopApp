package nticsnake;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class startpage  extends JPanel  {
	ImageIcon mainimg;
	startpage(){
		mainimg = new ImageIcon("src/nticsnake/stb.png");
	}
	
	public void paint(Graphics g) {
		mainimg.paintIcon(this, g, 0, 0);;
		
	}
	
	
}
