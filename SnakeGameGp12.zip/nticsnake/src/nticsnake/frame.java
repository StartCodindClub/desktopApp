package nticsnake;


import java.awt.Color;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class frame extends JFrame implements KeyListener {
	startpage strp = new startpage();
	lvl1 l1 = new lvl1();
	lvl2 l2 = new lvl2();
	JLabel text = new JLabel("F1 for LVL 1 Or F2 for LVL 2");	
	
	frame(){
		
		this.setTitle("Ntic Snake Game");
		this.setBackground(Color.DARK_GRAY);
		this.add(strp);
		this.setSize(868,690);
		this.setResizable(false);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.addKeyListener(this);
		this.addKeyListener(l1);
		this.addKeyListener(l2);
		
	}


	@Override
	public void keyTyped(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyCode()==KeyEvent.VK_F1) {
			if (l2.canreset ==1) {
				this.remove(strp);
				this.remove(l2);
				this.add(l1);
				this.validate();
				l1.restart ();
			}
		}
		
		if(e.getKeyCode()==KeyEvent.VK_F2) {
			if (l1.canreset == 1) {
				this.remove(strp);
				this.remove(l1);
				this.add(l2);
				this.validate();
				l2.restart ();
			}
		}
		
	}

	@Override
	public void keyReleased(KeyEvent e) {
		// TODO Auto-generated method stub
		
	}


	
	
	


	
}
