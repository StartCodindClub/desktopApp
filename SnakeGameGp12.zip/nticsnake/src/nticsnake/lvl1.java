package nticsnake;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JPanel;
import javax.swing.Timer;

public class lvl1 extends JPanel implements KeyListener,ActionListener{

	private int[] snakexlength=new int[750];
	private int[] snakeylength=new int[750];
	
	private boolean right=false;
	private boolean left=false;
	private boolean up=false;
	private boolean down=false;
	
	private ImageIcon rightmouth;
	private ImageIcon leftmouth;
	private ImageIcon upmouth;
	private ImageIcon downmouth;
	private ImageIcon snakeimage;
	
	private int[] enemyxpos= {0,25,50,75,100,125,150,175,200,225,250,275,300,325,350,375,400,425,450,475,500,525,550,575,
			600,625,650,675,700,725,750,775,800,825,850};
	
	private int[] enemyypos = {75,100,125,150,175,200,225,250,275,300,325,350,375,400,425,450,475,500,525,550,575,
			600,625};
	
	private ImageIcon enemyimage;
	
	private Random random=new Random();
	
	private int xpos = random.nextInt(34);
	private int ypos = random.nextInt(23);
	

	private Timer timer;
	private int delay=100;
	
	private int lengthofsnake=3;
	private int moves=0;
	private int scores=0;
	int canreset = 1 ;
	private ImageIcon titleImage;
	// /Users/mac/NetBeansProjects/nticsnake/src/nticsnake/rightmouth.png
	public lvl1() {
		addKeyListener(this);
		setFocusable(true);
		//setFocusTraversalKeysEnabled(true);
		timer=new Timer(delay,this);
		timer.start();
		snakeimage=new ImageIcon("src/nticsnake/snakeimage.png");
		downmouth=new ImageIcon("src/nticsnake/downmouth.png");
		upmouth=new ImageIcon("src/nticsnake/upmouth.png");
		leftmouth=new ImageIcon("src/nticsnake/leftmouth.png");
		rightmouth=new ImageIcon("src/nticsnake/rightmouth.png");
		titleImage = new ImageIcon("src/nticsnake/nticsnake1.png");
		

	}
	
	public void paint(Graphics g) {
		canreset = 0;
		if(moves==0)
		{
			snakexlength[0]=100;
			snakexlength[1]=75;
			snakexlength[2]=50;
			
			snakeylength[0]=100;
			snakeylength[1]=100;
			snakeylength[2]=100;
			
		}
		
		
		//border of title image
		g.setColor(Color.white);
		g.drawRect(0,8,851,55);
		titleImage.paintIcon(this, g, 1, 9);
		
		
		g.setColor(Color.BLACK);
		g.fillRect(0, 75, 875, 575);
		
		//draw the scores
		g.setColor(Color.WHITE);
		g.setFont(new Font("arial",Font.PLAIN,14));
		g.drawString("Scores : "+scores,770, 30);
		g.drawString("Length : "+lengthofsnake,770, 50);
		g.drawString("LVL 1",20, 40);
		

		rightmouth.paintIcon(this,g,snakexlength[0],snakeylength[0]);
		
		for(int i=0;i<lengthofsnake;i++)
		{
			if(i==0 && right)
			{
				rightmouth.paintIcon(this,g,snakexlength[i],snakeylength[i]);
			}
			if(i==0 && left)
			{
				leftmouth.paintIcon(this,g,snakexlength[i],snakeylength[i]);
			}
			if(i==0 && up)
			{
				upmouth.paintIcon(this,g,snakexlength[i],snakeylength[i]);
			}
			if(i==0 && down)
			{
				downmouth.paintIcon(this,g,snakexlength[i],snakeylength[i]);
			}
			
			if(i!=0)
			{
				snakeimage.paintIcon(this,g,snakexlength[i],snakeylength[i]);
			}
		}
		
		enemyimage = new ImageIcon("src/nticsnake/enemy.png");
		
		if(enemyxpos[xpos]==snakexlength[0] && enemyypos[ypos]==snakeylength[0])
		{
			lengthofsnake++;
			scores++;
			xpos = random.nextInt(34);
			ypos = random.nextInt(23);
		}
		enemyimage.paintIcon(this, g, enemyxpos[xpos], enemyypos[ypos]);
		
		
		
		for(int b=1;b<lengthofsnake;b++)
		{
			if(snakexlength[b]==snakexlength[0] && snakeylength[b]==snakeylength[0])
			{
				right=false;
				left=false;
				up=false;
				down=false;
				
				g.setColor(Color.WHITE);
				g.setFont(new Font("arial",Font.BOLD,50));
				g.drawString("Game Over!", 300, 300);
				
				g.setFont(new Font("arial",Font.BOLD,20));
				g.drawString("Spcae to RESTART Or F2 to play LVL2", 250, 340);
				
				timer.stop();
				canreset = 1;
			
				
			}
			
			
		}
		
		//g.dispose();
	}
	@Override
	public void actionPerformed(ActionEvent arg0) {
		
		if(right)
		{
			for(int i=lengthofsnake-1;i>=0;i--)
			{
				snakeylength[i+1]=snakeylength[i];
			}
			for(int i=lengthofsnake;i>=0;i--)
			{
				if(i==0)
				{
					snakexlength[i]=snakexlength[i]+25;
				}
				else
				{
					snakexlength[i]=snakexlength[i-1];
				}
			if(snakexlength[i]>825)
				{
					snakexlength[i]=0;
				}
			}
			
			repaint();
		}
		if(left)
		{
			for(int i=lengthofsnake-1;i>=0;i--)
			{
				snakeylength[i+1]=snakeylength[i];
			}
			for(int i=lengthofsnake;i>=0;i--)
			{
				if(i==0)
				{
					snakexlength[i]=snakexlength[i]-25;
				}
				else
				{
					snakexlength[i]=snakexlength[i-1];
				}
				if(snakexlength[i]<0)
				{
					snakexlength[i]=825;
				}
			}
			
			repaint();
		}
		
		if(up)
		{
			for(int i=lengthofsnake-1;i>=0;i--)
			{
				snakexlength[i+1]=snakexlength[i];
			}
			for(int i=lengthofsnake;i>=0;i--)
			{
				if(i==0)
				{
					snakeylength[i]=snakeylength[i]-25;
				}
				else
				{
					snakeylength[i]=snakeylength[i-1];
				}
				if(snakeylength[i]<75)
				{
					snakeylength[i]=625;
				}
			}
			
			repaint();
		}
		if(down)
		{
			for(int i=lengthofsnake-1;i>=0;i--)
			{
				snakexlength[i+1]=snakexlength[i];
			}
			for(int i=lengthofsnake;i>=0;i--)
			{
				if(i==0)
				{
					snakeylength[i]=snakeylength[i]+25;
				}
				else
				{
					snakeylength[i]=snakeylength[i-1];
				}
				if(snakeylength[i]>625)
				{
					snakeylength[i]=75;
				}
			}
			
			repaint();
		}
		
	}
	
	@Override
	public void keyPressed(KeyEvent e) {
		
		if(e.getKeyCode()==KeyEvent.VK_RIGHT)
		{
			moves++;
			if(!left)
			{
				up=false;
				down=false;
				left=false;
				right=true;
			}

		}
		if(e.getKeyCode()==KeyEvent.VK_LEFT)
		{
			moves++;
			if(!right)
			{
				left=true;
				up=false;
				down=false;
				right=false;
			}
		}
		if(e.getKeyCode()==KeyEvent.VK_UP)
		{
			moves++;
			if(!down)
			{
				up=true;
				down=false;
				left=false;
				right=false;
			}
		}
		if(e.getKeyCode()==KeyEvent.VK_DOWN)
		{
			moves++;
			if(!up)
			{
				down=true;
				up=false;
				left=false;
				right=false;
			}
		}
		
		if(e.getKeyCode()==KeyEvent.VK_SPACE)
		{
			restart ();
		}
		
		
	}
	
	
	
	public void restart () {
		if (canreset == 1 ) {
			scores=0;
			moves=0;
			lengthofsnake=3;
			timer.start();
			canreset = 0;
			repaint();
		}
	}
	
	
	
	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub
		
	}
	
	
	}
